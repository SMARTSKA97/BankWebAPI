﻿//using Microsoft.EntityFrameworkCore;

//namespace BankWebAPI
//{
//    public class Startup
//    {
//        public void ConfigureServices(IServiceCollection services)
//        {
//            services.AddControllers();

//            services.AddDbContext<ApplicationDbContext>(
//                options => options.UseNpgsql("name=ConnectionStrings:DefaultSQLConnection"));
//        }
//    }
//}
